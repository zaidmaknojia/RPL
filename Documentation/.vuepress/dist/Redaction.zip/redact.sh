#!/bin/bash

#variables in bash are $1, $2 etc

java -jar redaction.jar $1